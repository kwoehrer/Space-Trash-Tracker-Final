# Installation
> `npm install --save @types/semver`

# Summary
This package contains type definitions for semver (https://github.com/npm/node-semver).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/semver

Additional Details
 * Last updated: Mon, 29 Jan 2018 21:19:40 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bart van der Schoor <https://github.com/Bartvds>, BendingBender <https://github.com/BendingBender>, Lucian Buzzo <https://github.com/LucianBuzzo>.
