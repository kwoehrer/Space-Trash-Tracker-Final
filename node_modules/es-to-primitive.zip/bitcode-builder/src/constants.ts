export let BOOL_WIDTH = 1;
