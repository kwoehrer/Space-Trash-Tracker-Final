export type Linkage =
  'external' | 'weak' | 'appending' | 'internal' | 'linkonce' | 'dllimport' |
  'dllexport' | 'extern_weak' | 'common' | 'private' | 'weak_odr' |
  'linkonce_odr' | 'available_externally';
