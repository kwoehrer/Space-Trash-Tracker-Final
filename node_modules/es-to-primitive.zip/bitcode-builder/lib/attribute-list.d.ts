export declare type Attribute = {
    key: 'align' | 'alignstack' | 'dereferenceable' | 'dereferenceable_or_null';
    value: number;
} | {
    key: string;
    value: string;
} | 'alwaysinline' | 'byval' | 'inlinehint' | 'inreg' | 'minsize' | 'naked' | 'nest' | 'noalias' | 'nobuiltin' | 'nocapture' | 'noduplicates' | 'noimplictfloat' | 'noinline' | 'nonlazybind' | 'noredzone' | 'noreturn' | 'nounwind' | 'optsize' | 'readnone' | 'readonly' | 'returned' | 'returns_twice' | 'signext' | 'ssp' | 'sspreq' | 'sspstrong' | 'sret' | 'sanitize_address' | 'sanitize_thread' | 'sanitize_memory' | 'uwtable' | 'zeroext' | 'builtin' | 'cold' | 'optnone' | 'inalloca' | 'nonnull' | 'jumptable' | 'convergent' | 'safestack' | 'argmemonly' | 'swiftself' | 'swifterror' | 'norecurse' | 'inaccessiblememonly' | 'inaccessiblememonly_or_argmemonly' | 'writeonly' | 'speculatable' | 'strictfp' | 'sanitize_hwaddress' | string;
export declare class AttributeList {
    private list;
    add(attr: Attribute | ReadonlyArray<Attribute>): boolean;
    delete(attr: Attribute | ReadonlyArray<Attribute>): boolean;
    [Symbol.iterator](): Iterator<Attribute>;
}
