export declare function validateName(name: string): boolean;
