import * as values from '../';
import { Type } from '../../types';
import { Instruction } from './base';
export declare type CastType = 'trunc' | 'zext' | 'sext' | 'fptoui' | 'fptosi' | 'uitofp' | 'sitofp' | 'fptrunc' | 'fpext' | 'ptrtoint' | 'inttoptr' | 'bitcast' | 'addrspacecast';
export declare class Cast extends Instruction {
    readonly castType: CastType;
    readonly operand: values.Value;
    readonly targetType: Type;
    constructor(castType: CastType, operand: values.Value, targetType: Type);
}
