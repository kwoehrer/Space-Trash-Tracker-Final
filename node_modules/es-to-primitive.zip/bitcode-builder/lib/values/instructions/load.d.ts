import * as values from '../';
import { Instruction } from './base';
export declare class Load extends Instruction {
    readonly ptr: values.Value;
    readonly alignment: number | undefined;
    readonly isVolatile: boolean;
    constructor(ptr: values.Value, alignment?: number | undefined, isVolatile?: boolean);
}
