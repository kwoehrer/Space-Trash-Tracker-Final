import { Instruction } from './base';
export declare class Unreachable extends Instruction {
    constructor();
}
