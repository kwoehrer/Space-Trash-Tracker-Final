import * as types from '../../types';
import { Constant } from './base';
export declare class Struct extends Constant {
    readonly fields: ReadonlyArray<Constant>;
    constructor(ty: types.Struct, fields: ReadonlyArray<Constant>);
    isEqual(to: Constant): boolean;
    toString(): string;
}
