import { Type } from '../types';
import { Value } from './base';
export declare class Argument extends Value {
    readonly index: number;
    readonly name: string;
    constructor(ty: Type, index: number, name: string);
    toString(): string;
}
