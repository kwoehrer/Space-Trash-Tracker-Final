import * as values from '../values';
import { Type } from './base';
export declare class Metadata extends Type {
    constructor();
    ptr(): never;
    isEqual(to: Type): boolean;
    val(value: values.constants.MetadataValue): values.constants.Metadata;
}
