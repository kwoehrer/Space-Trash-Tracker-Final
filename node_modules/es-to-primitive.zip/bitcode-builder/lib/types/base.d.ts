import * as types from '../types';
import * as values from '../values';
export declare abstract class Type {
    private privTypeString;
    constructor(privTypeString: string);
    readonly typeString: string;
    ptr(): types.Pointer;
    val(_: any): values.Value;
    undef(): values.constants.Undef;
    isVoid(): boolean;
    isInt(): boolean;
    isLabel(): boolean;
    isMetadata(): boolean;
    isPointer(): boolean;
    isSignature(): boolean;
    isStruct(): boolean;
    isArray(): boolean;
    toVoid(): types.Void;
    toInt(): types.Int;
    toLabel(): types.Label;
    toMetadata(): types.Metadata;
    toPointer(): types.Pointer;
    toSignature(): types.Signature;
    toStruct(): types.Struct;
    toArray(): types.Array;
    abstract isEqual(to: Type): boolean;
}
