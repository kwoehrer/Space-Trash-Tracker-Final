import { Type } from './base';
export declare class Label extends Type {
    constructor();
    isEqual(to: Type): boolean;
}
