/// <reference types="node" />
import { BitStream } from '../bitstream';
import { Block } from './base';
export interface IStrtabEntry {
    readonly buffer: Buffer;
    readonly offset: number;
    readonly length: number;
}
export declare class StrtabBlock extends Block {
    private readonly list;
    private readonly map;
    private totalSize;
    add(str: string): IStrtabEntry;
    build(writer: BitStream): void;
}
