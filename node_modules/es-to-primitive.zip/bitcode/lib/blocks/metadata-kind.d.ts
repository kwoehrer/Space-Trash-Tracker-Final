import { BitStream } from '../bitstream';
import { Block } from './base';
export declare class MetadataKindBlock extends Block {
    private readonly map;
    constructor(map: ReadonlyMap<string, number>);
    build(writer: BitStream): void;
}
