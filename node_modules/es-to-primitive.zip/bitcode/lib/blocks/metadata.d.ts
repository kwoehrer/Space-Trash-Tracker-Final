import { values } from 'bitcode-builder';
import { BitStream, BlockInfoMap } from '../bitstream';
import { Enumerator } from '../enumerator';
import { Block } from './base';
import { TypeBlock } from './type';
import Metadata = values.constants.Metadata;
export declare class MetadataBlock extends Block {
    private readonly enumerator;
    private readonly typeBlock;
    static buildInfo(info: BlockInfoMap): void;
    private readonly map;
    private readonly strings;
    private readonly values;
    private readonly tuples;
    constructor(enumerator: Enumerator, typeBlock: TypeBlock, list: ReadonlyArray<Metadata>);
    get(metadata: Metadata): number;
    build(writer: BitStream): void;
    private add(metadata);
    private addString(value);
    private addTuple(metadata, operands);
    private addValue(value);
    private getEntry(entry);
    private buildStrings(writer);
    private buildValues(writer);
    private buildTuples(writer);
}
