import { IWriter } from './abbr';
import { Operand } from './operand';
declare class ArrayOp extends Operand {
    readonly elemOp: Operand;
    constructor(elemOp: Operand);
    encode(writer: IWriter, value?: any): void;
}
export { ArrayOp as Array };
