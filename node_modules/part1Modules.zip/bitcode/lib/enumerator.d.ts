import { values } from 'bitcode-builder';
import constants = values.constants;
import Constant = constants.Constant;
import Metadata = constants.Metadata;
export interface IEnumeratorInput {
    readonly decls: ReadonlyArray<constants.Declaration>;
    readonly fns: ReadonlyArray<constants.Func>;
    readonly globals: ReadonlyArray<values.Global>;
}
export declare type ConstantList = ReadonlyArray<Constant>;
export declare class Enumerator {
    private globals;
    private map;
    private index;
    private lastGlobalIndex;
    private globalConstants;
    private functionConstants;
    private functionMetadata;
    private metadataKinds;
    private lastEmittedIndex;
    private constList;
    private metadataList;
    enumerate(input: IEnumeratorInput): void;
    get(value: values.Value): number;
    [Symbol.iterator](): Iterator<values.Value>;
    getGlobalConstants(): ConstantList;
    getFunctionConstants(fn: constants.Func): ConstantList;
    getMetadataKinds(): ReadonlyMap<string, number>;
    getFunctionMetadata(fn: constants.Func): ReadonlyArray<Metadata>;
    checkValueOrder(value: values.Value): void;
    leaveFunction(): void;
    private enumerateValue(value, mode?);
    private enumerateGlobal(global);
    private enumerateGlobalConst(c);
    private enumerateFunction(fn);
    private enumerateDeclaration(decl);
    private enumerateBlock(bb, mode);
    private enumerateMetadata(metadata);
}
