/// <reference types="node" />
export declare class ByteWriter {
    private size;
    private current;
    private chunkOffset;
    private chunkLeft;
    private chunks;
    readonly offset: number;
    writeByte(value: number): ByteWriter;
    writeWord(value: number): ByteWriter;
    writeDWord(value: number): ByteWriter;
    reserve(bytes: number): Buffer;
    end(): Buffer;
    private push(chunk);
    private ensureChunk();
    private flush();
}
