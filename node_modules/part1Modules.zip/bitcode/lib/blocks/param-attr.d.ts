import { values } from 'bitcode-builder';
import { BitStream } from '../bitstream';
import { Block } from './base';
import constants = values.constants;
export declare type ParamEntryIndex = number;
export declare class ParamAttrBlock extends Block {
    private groupCache;
    private groups;
    private entries;
    private map;
    addDecl(decl: constants.Declaration): void;
    addGlobal(global: values.Global): void;
    get(value: values.Value): ParamEntryIndex | undefined;
    build(writer: BitStream): void;
    private addGroup(paramIndex, attrList, to);
}
