import { BitStream, BlockInfoMap } from '../bitstream';
import { ConstantList, Enumerator } from '../enumerator';
import { Block } from './base';
import { TypeBlock } from './type';
export declare class ConstantBlock extends Block {
    private readonly enumerator;
    private readonly typeBlock;
    private readonly list;
    static buildInfo(info: BlockInfoMap): void;
    constructor(enumerator: Enumerator, typeBlock: TypeBlock, list: ConstantList);
    build(writer: BitStream): void;
}
