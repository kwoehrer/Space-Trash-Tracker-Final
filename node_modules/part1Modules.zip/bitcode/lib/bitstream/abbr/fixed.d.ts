import { IWriter } from './abbr';
import { Operand } from './operand';
export declare class Fixed extends Operand {
    readonly width: number;
    constructor(width: number);
    encode(writer: IWriter, value?: any): void;
}
