import { IWriter } from './abbr';
import { Operand } from './operand';
export declare class Blob extends Operand {
    constructor();
    encode(writer: IWriter, value?: any): void;
}
