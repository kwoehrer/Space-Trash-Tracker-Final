/// <reference types="node" />
import { Abbr } from './abbr';
import { VBRValue } from './vbr-value';
export interface IBitStreamOptions {
    readonly magic: number | undefined;
}
export declare type BlockInfoMap = Map<number, Abbr[]>;
export declare class BitStream {
    private readonly writer;
    private readonly stack;
    private blockInfo;
    constructor(options?: IBitStreamOptions);
    enterBlock(id: number, abbrIDWidth: number): BitStream;
    endBlock(id: number): BitStream;
    writeBlockInfo(map: BlockInfoMap): BitStream;
    defineAbbr(abbr: Abbr): BitStream;
    hasAbbr(abbrName: string): boolean;
    writeRecord(abbrName: string, values: ReadonlyArray<any>): BitStream;
    writeUnabbrRecord(code: number, values: ReadonlyArray<VBRValue>): BitStream;
    end(): Buffer;
    writeVBR(value: VBRValue, width: number): BitStream;
    writeBits(value: number, width: number): BitStream;
    writeByte(value: number): BitStream;
    writeWord(value: number): BitStream;
    writeDWord(value: number): BitStream;
    align(width: number): BitStream;
    private writeVBR64(hi, lo, width);
    private writeAbbrID(id);
}
