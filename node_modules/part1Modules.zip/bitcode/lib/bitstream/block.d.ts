import { Abbr } from './abbr';
export interface IAbbrMapEntry {
    readonly abbr: Abbr;
    readonly index: number;
}
export declare class Block {
    readonly id: number;
    readonly abbrIDWidth: number;
    protected abbrList: Abbr[];
    protected abbrMap: Map<string, IAbbrMapEntry>;
    constructor(id: number, abbrIDWidth: number, globalAbbrs: ReadonlyArray<Abbr>);
    addAbbr(abbr: Abbr): number;
    getAbbr(name: string): IAbbrMapEntry | undefined;
    hasAbbr(name: string): boolean;
}
