export declare type VBRValue = number | [number, number];
