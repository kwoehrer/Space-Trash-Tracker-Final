export type VBRValue = number | [ number, number ];
