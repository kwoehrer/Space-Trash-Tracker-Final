# C137.js

C137.js is an es6 [Cesium](https://cesiumjs.org) distribution that is compact, offline-capable, and simple to use.

<br>

## Installation

```bash
npm install c137.js
```

<br>

## Usage

```javascript
import { Viewer } from "c137.js";
viewer = new Viewer("cesiumContainer");
```

<br>

## Contact

[info@digitalarsenal.io](mailto:info@digitalarsenal.io)

<br>

## Digital Signature Information

---

<br>

#### **BlockChain**: &nbsp;&nbsp;&nbsp; Bitcoin (BTC) MainNet

<br>

#### **[SRI](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity)**: &nbsp;&nbsp;&nbsp; EgfdEtKfPSZARjx6lj+D4jMSYszjSbJLXx7jF0vZ1n8=

<br>

#### **SIGNING KEY ADDRESS**: &nbsp;&nbsp;&nbsp; [1o1oiXfMHPXMY6kxeZfXSHsYKWp9DqtU7](https://live.blockcypher.com/btc/address/1o1oiXfMHPXMY6kxeZfXSHsYKWp9DqtU7)

<br>

#### **SIGNATURE**: &nbsp;&nbsp;&nbsp; IOjZXBHN8lAIuS/tT3jO4bnk/kbYQmxL4adk2m1ZrAHaIgUWsGE1sDwjtVlQfKZ3qgN0AjyF+4+xLUS2W6rtkCU=


<br>

## Contribute

BTC: [3HupNP44FQxywYRbepYLSJnDNmQmaFWuh1](https://live.blockcypher.com/btc/address/3HupNP44FQxywYRbepYLSJnDNmQmaFWuh1)

LTC: [MF8S8CJQaCKCMuMJXJummDaRbhuDsnEWTf](https://live.blockcypher.com/ltc/address/MF8S8CJQaCKCMuMJXJummDaRbhuDsnEWTf/)

ETH: [0x1506c2Ad00f9c6c6B0B8719305DB487164c29E99](https://etherscan.io/address/0x1506c2Ad00f9c6c6B0B8719305DB487164c29E99)

XTZ: [tz1dYjYNGsRbEyF8p8vToHbVUTmKvcoaW39j](https://tezblock.io/account/tz1dYjYNGsRbEyF8p8vToHbVUTmKvcoaW39j)

<br>

## Licenses

[Apache 2.0](https://choosealicense.com/licenses/apache-2.0/)

[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
