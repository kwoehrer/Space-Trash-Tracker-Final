declare class InfoCommand {
    apply(cli: any): Promise<void>;
}
export default InfoCommand;
