import * as values from '../values';
import { Type } from './base';
export declare class Signature extends Type {
    readonly returnType: Type;
    readonly params: ReadonlyArray<Type>;
    constructor(returnType: Type, params: ReadonlyArray<Type>);
    isEqual(to: Type): boolean;
    declareFunction(name: string): values.constants.Declaration;
    defineFunction(name: string, paramNames: ReadonlyArray<string>): values.constants.Func;
}
