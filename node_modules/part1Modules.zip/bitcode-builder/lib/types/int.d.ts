import * as values from '../values';
import { Type } from './base';
export declare class Int extends Type {
    readonly width: number;
    constructor(width: number);
    isEqual(to: Type): boolean;
    val(num: number): values.constants.Int;
}
