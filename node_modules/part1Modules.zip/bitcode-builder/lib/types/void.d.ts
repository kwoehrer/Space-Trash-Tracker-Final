import { Type } from './base';
export declare class Void extends Type {
    constructor();
    ptr(): never;
    isEqual(to: Type): boolean;
}
