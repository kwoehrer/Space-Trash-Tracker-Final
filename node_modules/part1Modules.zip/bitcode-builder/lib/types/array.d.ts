import * as values from '../values';
import { Type } from './base';
declare class ArrayTy extends Type {
    readonly length: number;
    readonly elemType: Type;
    constructor(length: number, elemType: Type);
    isEqual(to: Type): boolean;
    val(elems: values.constants.Constant[]): values.constants.Array;
}
export { ArrayTy as Array };
