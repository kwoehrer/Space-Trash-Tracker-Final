import { AttributeList } from '../../attribute-list';
import { CallingConv } from '../../calling-conv';
import { Linkage } from '../../linkage';
import { Signature } from '../../types';
import { Constant } from './base';
export declare class Declaration extends Constant {
    readonly name: string;
    readonly returnAttrs: AttributeList;
    readonly attrs: AttributeList;
    linkage: Linkage;
    cconv: CallingConv;
    readonly paramAttrs: ReadonlyArray<AttributeList>;
    constructor(signature: Signature, name: string);
    isEqual(to: Constant): boolean;
    toString(): string;
}
