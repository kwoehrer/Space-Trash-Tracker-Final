import { Signature } from '../../types';
import { Argument, BasicBlock } from '../../values';
import { Declaration } from './declaration';
import { Metadata } from './metadata';
export declare class Func extends Declaration {
    private readonly paramNames;
    readonly args: ReadonlyArray<Argument>;
    readonly body: BasicBlock;
    readonly metadata: Map<string, Metadata>;
    private readonly paramMap;
    private blockList;
    constructor(signature: Signature, name: string, paramNames: ReadonlyArray<string>);
    toString(): string;
    createBlock(name?: string): BasicBlock;
    getArgument(name: string): Argument;
    [Symbol.iterator](): Iterator<BasicBlock>;
}
