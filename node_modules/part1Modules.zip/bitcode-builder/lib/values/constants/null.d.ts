import * as types from '../../types';
import { Constant } from './base';
export declare class Null extends Constant {
    constructor(ty: types.Pointer);
    isEqual(to: Constant): boolean;
    toString(): string;
}
