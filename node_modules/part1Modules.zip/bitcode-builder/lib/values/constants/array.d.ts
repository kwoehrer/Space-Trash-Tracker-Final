import * as types from '../../types';
import { Constant } from './base';
declare class ArrayVal extends Constant {
    readonly elems: ReadonlyArray<Constant>;
    constructor(ty: types.Array, elems: ReadonlyArray<Constant>);
    isEqual(to: Constant): boolean;
    toString(): string;
}
export { ArrayVal as Array };
