import * as values from '../';
import { Instruction } from './base';
export interface ISwitchCase {
    readonly value: values.constants.Int;
    readonly block: values.BasicBlock;
}
export declare class Switch extends Instruction {
    readonly condition: values.Value;
    readonly otherwise: values.BasicBlock;
    readonly cases: ISwitchCase[];
    constructor(condition: values.Value, otherwise: values.BasicBlock, cases: ISwitchCase[]);
}
