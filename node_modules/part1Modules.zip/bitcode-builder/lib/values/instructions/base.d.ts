import { Type } from '../../types';
import { Value } from '../base';
import { Metadata } from '../constants';
export declare abstract class Instruction extends Value {
    readonly opcode: string;
    protected readonly operands: Value[];
    readonly metadata: Map<string, Metadata>;
    constructor(ty: Type, opcode: string, operands: Value[]);
    isExtractValue(): boolean;
    isInsertValue(): boolean;
    isGetElementPtr(): boolean;
    isUnreachable(): boolean;
    [Symbol.iterator](): Iterator<Value>;
    toString(): string;
}
