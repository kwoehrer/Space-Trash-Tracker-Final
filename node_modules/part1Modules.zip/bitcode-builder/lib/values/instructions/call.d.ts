import * as values from '../';
import { CallingConv } from '../../calling-conv';
import { Signature } from '../../types';
import { Instruction } from './base';
export declare type CallType = 'normal' | 'tail' | 'musttail' | 'notail';
export declare class Call extends Instruction {
    readonly callee: values.Value;
    readonly args: ReadonlyArray<values.Value>;
    readonly callType: CallType;
    readonly cconv: CallingConv;
    readonly calleeSignature: Signature;
    constructor(callee: values.Value, args: ReadonlyArray<values.Value>, callType?: CallType, cconv?: CallingConv);
}
