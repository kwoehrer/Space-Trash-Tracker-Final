import * as values from '../';
import { Instruction } from './base';
export declare class Store extends Instruction {
    readonly value: values.Value;
    readonly ptr: values.Value;
    readonly alignment: number | undefined;
    readonly isVolatile: boolean;
    constructor(value: values.Value, ptr: values.Value, alignment?: number | undefined, isVolatile?: boolean);
}
