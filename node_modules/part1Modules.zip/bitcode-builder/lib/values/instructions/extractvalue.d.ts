import * as values from '../';
import { Instruction } from './base';
export declare class ExtractValue extends Instruction {
    readonly aggr: values.Value;
    readonly index: number;
    constructor(aggr: values.Value, index: number);
}
