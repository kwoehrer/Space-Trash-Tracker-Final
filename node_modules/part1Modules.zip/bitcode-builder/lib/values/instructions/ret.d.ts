import * as values from '../';
import { Instruction } from './base';
export declare class Ret extends Instruction {
    readonly operand: values.Value | undefined;
    constructor(operand?: values.Value | undefined);
}
