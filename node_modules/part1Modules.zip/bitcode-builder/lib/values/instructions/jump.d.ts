import * as values from '../';
import { Instruction } from './base';
export declare class Jump extends Instruction {
    readonly target: values.BasicBlock;
    constructor(target: values.BasicBlock);
}
