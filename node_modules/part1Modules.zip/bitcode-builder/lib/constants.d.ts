export declare let BOOL_WIDTH: number;
