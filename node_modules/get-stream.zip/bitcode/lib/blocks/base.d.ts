import { BitStream } from '../bitstream';
export declare abstract class Block {
    private isBuilt;
    build(writer: BitStream): void;
    protected checkBuilt(): void;
    protected checkNotBuilt(): void;
}
