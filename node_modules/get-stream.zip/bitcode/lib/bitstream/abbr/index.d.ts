import { Array } from './array';
import { Blob } from './blob';
import { Char6 } from './char6';
import { Fixed } from './fixed';
import { Literal } from './literal';
import { VBR } from './vbr';
export { Abbr } from './abbr';
export { Operand } from './operand';
export declare const operands: {
    Array: typeof Array;
    Blob: typeof Blob;
    Char6: typeof Char6;
    Fixed: typeof Fixed;
    Literal: typeof Literal;
    VBR: typeof VBR;
};
