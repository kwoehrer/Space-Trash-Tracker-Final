export declare const BLOCK_ID: {
    CONSTANTS: number;
    FUNCTION: number;
    METADATA: number;
    METADATA_ATTACHMENT: number;
    METADATA_KIND: number;
    MODULE: number;
    PARAMATTR: number;
    PARAMATTR_GROUP: number;
    STRTAB: number;
    TYPE: number;
    VALUE_SYMTAB: number;
};
export declare const MODULE_CODE: {
    FUNCTION: number;
    GLOBALVAR: number;
    SOURCE_FILENAME: number;
    VERSION: number;
};
export declare const TYPE_CODE: {
    ARRAY: number;
    DOUBLE: number;
    FLOAT: number;
    FP128: number;
    FUNCTION: number;
    HALF: number;
    INTEGER: number;
    LABEL: number;
    METADATA: number;
    NUMENTRY: number;
    OPAQUE: number;
    POINTER: number;
    PPC_FP128: number;
    STRUCT_ANON: number;
    STRUCT_NAME: number;
    STRUCT_NAMED: number;
    VECTOR: number;
    VOID: number;
    X86_FP80: number;
    X86_MMX: number;
};
export declare const STRTAB_CODE: {
    BLOB: number;
};
export declare const CONSTANTS_CODE: {
    AGGREGATE: number;
    BLOCKADDRESS: number;
    CSTRING: number;
    DATA: number;
    FLOAT: number;
    INTEGER: number;
    NULL: number;
    SETTYPE: number;
    STRING: number;
    UNDEF: number;
    WIDE_INTEGER: number;
};
export declare const FUNCTION_CODE: {
    DEBUG_LOC: number;
    DEBUG_LOC_AGAIN: number;
    DECLAREBLOCKS: number;
    INST_ALLOCA: number;
    INST_ATOMICRMW: number;
    INST_BINOP: number;
    INST_BR: number;
    INST_CALL: number;
    INST_CAST: number;
    INST_CATCHPAD: number;
    INST_CATCHRET: number;
    INST_CLEANSWITCH: number;
    INST_CLEANUPPAD: number;
    INST_CLEANUPRET: number;
    INST_CMP: number;
    INST_CMP2: number;
    INST_CMPXCHG: number;
    INST_EXTRACTELT: number;
    INST_EXTRACTVAL: number;
    INST_FENCE: number;
    INST_GEP: number;
    INST_INSERTELT: number;
    INST_INSERTVAL: number;
    INST_INVOKE: number;
    INST_LANDINGPAD: number;
    INST_LOAD: number;
    INST_LOADATOMIC: number;
    INST_PHI: number;
    INST_RESUME: number;
    INST_RET: number;
    INST_SELECT: number;
    INST_SHUFFLEVEC: number;
    INST_STORE: number;
    INST_STOREATOMIC: number;
    INST_SWITCH: number;
    INST_UNREACHABLE: number;
    INST_VAARG: number;
    INST_VSELECT: number;
    OPERAND_BUNDLE: number;
};
export declare const VALUE_SYMTAB_CODE: {
    BBENTRY: number;
    COMBINED_ENTRY: number;
    ENTRY: number;
    FNENTRY: number;
};
export declare const PARAMATTR_CODE: {
    ENTRY: number;
};
export declare const PARAMATTR_GROUP_CODE: {
    ENTRY: number;
};
export declare const METADATA_CODE: {
    DISTINCT_NODE: number;
    NODE: number;
    STRINGS: number;
    VALUE: number;
};
export declare const METADATA_ATTACHMENT_CODE: {
    ATTACHMENT: number;
};
export declare const METADATA_KIND_CODE: {
    KIND: number;
};
export declare const FIXED: {
    BINOP_TYPE: number;
    BOOL: number;
    CAST_TYPE: number;
    CHAR: number;
    LINKAGE: number;
    PREDICATE: number;
    VISIBILITY: number;
};
export declare const VBR: {
    ALIGNMENT: number;
    ARRAY_LENGTH: number;
    ATTR_INDEX: number;
    BLOCK_COUNT: number;
    BLOCK_INDEX: number;
    CCONV: number;
    INTEGER: number;
    INT_WIDTH: number;
    METADATA_INDEX: number;
    METADATA_KIND_INDEX: number;
    METADATA_STRING_COUNT: number;
    METADATA_STRING_OFF: number;
    STRTAB_LENGTH: number;
    STRTAB_OFFSET: number;
    TYPE_INDEX: number;
    VALUE_INDEX: number;
};
export declare const VISIBILITY: {
    DEFAULT: number;
    HIDDEN: number;
    PROTECTED: number;
};
export declare const UNNAMED_ADDR: {
    LOCAL_UNNAMED_ADDR: number;
    NO: number;
    UNNAMED_ADDR: number;
};
export declare const CALL_FLAG_SHIFTS: {
    CCONV: number;
    EXPLICIT_TYPE: number;
    MUSTTAIL: number;
    NOTAIL: number;
    TAIL: number;
};
export declare const KNOWN_ATTRIBUTES: {
    [key: string]: number;
};
