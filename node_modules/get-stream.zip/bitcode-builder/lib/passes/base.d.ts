import * as values from '../values';
export interface IPassInput {
    readonly declarations: values.constants.Declaration[];
    readonly functions: values.constants.Func[];
    readonly globals: values.Global[];
}
export declare abstract class Pass {
    protected readonly input: IPassInput;
    constructor(input: IPassInput);
    abstract run(): void;
}
