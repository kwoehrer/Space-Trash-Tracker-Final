/// <reference types="node" />
import { Attribute, AttributeList } from './attribute-list';
import { CallingConv } from './calling-conv';
import { Linkage } from './linkage';
import * as passes from './passes';
import * as types from './types';
import * as values from './values';
import Type = types.Type;
import constants = values.constants;
export declare class Builder {
    static void(): types.Void;
    static i(width: number): types.Int;
    static signature(returnType: Type, params: Type[]): types.Signature;
    static array(length: number, elemType: Type): types.Array;
    static struct(name?: string): types.Struct;
    static global(ty: types.Type, name: string, init?: constants.Constant): values.Global;
    static cstring(value: string): constants.Array;
    static blob(buffer: Buffer): constants.Array;
    static metadata(value: constants.MetadataValue): constants.Metadata;
    void(): types.Void;
    i(width: number): types.Int;
    signature(returnType: Type, params: Type[]): types.Signature;
    array(length: number, elemType: Type): types.Array;
    struct(name?: string): types.Struct;
    global(ty: types.Type, name: string, init?: constants.Constant): values.Global;
    cstring(value: string): constants.Array;
    blob(buffer: Buffer): constants.Array;
    metadata(value: constants.MetadataValue): constants.Metadata;
}
export { passes, types, values, Attribute, AttributeList, CallingConv, Linkage };
