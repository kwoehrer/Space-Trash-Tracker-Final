import * as types from '../../types';
import { Constant } from './base';
export declare class Int extends Constant {
    readonly value: number;
    constructor(ty: types.Int, value: number);
    isEqual(to: Constant): boolean;
    toString(): string;
}
