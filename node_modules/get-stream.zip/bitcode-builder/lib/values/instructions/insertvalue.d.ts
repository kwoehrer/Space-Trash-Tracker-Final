import * as values from '../';
import { Instruction } from './base';
export declare class InsertValue extends Instruction {
    readonly aggr: values.Value;
    readonly element: values.Value;
    readonly index: number;
    constructor(aggr: values.Value, element: values.Value, index: number);
}
