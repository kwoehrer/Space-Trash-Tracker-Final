import * as values from '../';
import { Instruction } from './base';
export declare class GetElementPtr extends Instruction {
    readonly ptr: values.Value;
    readonly ptrIndex: values.Value;
    readonly index: values.Value | undefined;
    readonly inbounds: boolean;
    constructor(ptr: values.Value, ptrIndex: values.Value, index?: values.Value | undefined, inbounds?: boolean);
}
