/// <reference types="node" />
import * as builder from 'bitcode-builder';
import Builder = builder.Builder;
import values = builder.values;
import constants = values.constants;
export { builder, Builder };
export declare class Module {
    readonly sourceName: string | undefined;
    private readonly usedNames;
    private readonly fns;
    private readonly decls;
    private readonly globals;
    private readonly enumerator;
    private readonly typeBlock;
    private readonly paramAttrBlock;
    private readonly strtab;
    constructor(sourceName?: string | undefined);
    addFunction(fn: constants.Func): void;
    addDeclaration(decl: constants.Declaration): void;
    addGlobal(g: values.Global): void;
    build(): Buffer;
    createBuilder(): builder.Builder;
    add(value: values.Value): Module;
    private verify();
    private defineBlockInfo(writer);
    private buildGlobals(writer, globals);
    private buildDeclarations(writer);
    private buildFunctionBodies(writer);
    private useGlobalName(name);
}
