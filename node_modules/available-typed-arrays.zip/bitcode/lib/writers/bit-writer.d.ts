/// <reference types="node" />
export declare class BitWriter {
    private readonly writer;
    private dword;
    private dwordLeft;
    private dwordOff;
    readonly offset: number;
    readonly bitOffset: number;
    writeBits(value: number, width: number): BitWriter;
    writeByte(value: number): BitWriter;
    writeWord(value: number): BitWriter;
    writeDWord(value: number): BitWriter;
    pad(width: number): BitWriter;
    align(width: number): BitWriter;
    reserve(width: number): Buffer;
    end(): Buffer;
    private flush();
}
