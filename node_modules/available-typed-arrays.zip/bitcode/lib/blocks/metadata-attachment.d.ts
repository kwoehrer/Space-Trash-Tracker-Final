import { values } from 'bitcode-builder';
import { BitStream } from '../bitstream';
import { Block } from './base';
import { MetadataBlock } from './metadata';
import constants = values.constants;
export declare class MetadataAttachmentBlock extends Block {
    private readonly metadataBlock;
    private readonly fn;
    private kinds;
    constructor(metadataBlock: MetadataBlock, fn: constants.Func, kinds: ReadonlyMap<string, number>);
    build(writer: BitStream): void;
}
