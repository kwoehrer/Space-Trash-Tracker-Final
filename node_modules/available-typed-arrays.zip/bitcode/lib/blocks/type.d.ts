import { types } from 'bitcode-builder';
import { BitStream } from '../bitstream';
import { Block } from './base';
export declare class TypeBlock extends Block {
    private readonly indexMap;
    private readonly typeMap;
    add(ty: types.Type): void;
    get(ty: types.Type): number;
    build(writer: BitStream): void;
    private addSignature(sig);
    private addStruct(struct);
    private enumerate();
    private write(writer, ty);
    private writeArray(writer, ty);
    private writeInt(writer, ty);
    private writeLabel(writer, ty);
    private writePointer(writer, ty);
    private writeSignature(writer, ty);
    private writeStruct(writer, ty);
    private writeVoid(writer, ty);
}
