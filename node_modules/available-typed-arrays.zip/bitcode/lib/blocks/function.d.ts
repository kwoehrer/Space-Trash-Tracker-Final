import { values } from 'bitcode-builder';
import { BitStream, BlockInfoMap } from '../bitstream';
import { Enumerator } from '../enumerator';
import { Block } from './base';
import { TypeBlock } from './type';
import constants = values.constants;
export declare class FunctionBlock extends Block {
    private readonly enumerator;
    private readonly typeBlock;
    private readonly fn;
    static buildInfo(info: BlockInfoMap): void;
    constructor(enumerator: Enumerator, typeBlock: TypeBlock, fn: constants.Func);
    build(writer: BitStream): void;
    private buildInstruction(writer, instr, blockIds);
    private buildSymtab(writer, blocks);
}
