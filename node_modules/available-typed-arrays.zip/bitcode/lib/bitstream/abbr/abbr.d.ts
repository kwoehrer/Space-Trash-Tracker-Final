import { VBRValue } from '../vbr-value';
import { Array as ArrayOp } from './array';
import { Blob } from './blob';
import { Char6 } from './char6';
import { Fixed } from './fixed';
import { Literal } from './literal';
import { Operand } from './operand';
import { VBR } from './vbr';
export interface IWriter {
    writeVBR(val: VBRValue, encWidth: number): IWriter;
    writeBits(val: number, bits: number): IWriter;
    align(bits: number): IWriter;
}
export declare class Abbr {
    readonly name: string;
    readonly operands: ReadonlyArray<Operand>;
    static literal(value: number): Literal;
    static fixed(width: number): Fixed;
    static vbr(width: number): VBR;
    static array(elemOp: Operand): ArrayOp;
    static char6(): Char6;
    static blob(): Blob;
    private readonly operandCount;
    constructor(name: string, operands: ReadonlyArray<Operand>);
    writeDefinition(writer: IWriter): void;
    write(writer: IWriter, values: ReadonlyArray<any>): void;
}
