import { IWriter } from './abbr';
import { Operand } from './operand';
export declare class Char6 extends Operand {
    constructor();
    encode(writer: IWriter, value?: any): void;
}
