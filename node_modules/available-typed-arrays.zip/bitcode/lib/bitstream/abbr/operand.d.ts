import { IWriter } from './abbr';
export declare abstract class Operand {
    abstract encode(writer: IWriter, value?: any): void;
}
