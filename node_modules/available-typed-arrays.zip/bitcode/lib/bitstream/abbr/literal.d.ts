import { VBRValue } from '../vbr-value';
import { IWriter } from './abbr';
import { Operand } from './operand';
export declare class Literal extends Operand {
    readonly value: VBRValue;
    constructor(value: VBRValue);
    encode(writer: IWriter, _?: any): void;
}
