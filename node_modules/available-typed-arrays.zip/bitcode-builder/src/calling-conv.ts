export type CallingConv =
  'ccc' | 'fastcc' | 'coldcc' | 'webkit_jscc' | 'anyregcc' | 'preserve_mostcc' |
  'preserve_allcc' | 'swiftcc' | 'cxx_fast_tlscc' | 'x86_stdcallcc' |
  'x86_fastcallcc' | 'arm_apcscc' | 'arm_aapcscc' | 'arm_aapcs_vfpcc';
