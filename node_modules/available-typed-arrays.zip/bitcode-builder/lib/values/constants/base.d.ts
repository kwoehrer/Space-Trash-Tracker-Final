import { Value } from '../base';
import * as constants from './';
export declare abstract class Constant extends Value {
    abstract isEqual(to: Constant): boolean;
    isInt(): boolean;
    isArray(): boolean;
    isStruct(): boolean;
    isNull(): boolean;
    isUndef(): boolean;
    isMetadata(): boolean;
    isDeclaration(): boolean;
    isFunction(): boolean;
    toInt(): constants.Int;
    toArray(): constants.Array;
    toStruct(): constants.Struct;
    toNull(): constants.Null;
    toUndef(): constants.Undef;
    toMetadata(): constants.Metadata;
    toDeclaration(): constants.Declaration;
    toFunction(): constants.Func;
}
