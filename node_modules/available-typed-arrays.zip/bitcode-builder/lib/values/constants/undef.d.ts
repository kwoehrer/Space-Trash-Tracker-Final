import * as types from '../../types';
import { Constant } from './base';
export declare class Undef extends Constant {
    constructor(ty: types.Type);
    isEqual(to: Constant): boolean;
    toString(): string;
}
