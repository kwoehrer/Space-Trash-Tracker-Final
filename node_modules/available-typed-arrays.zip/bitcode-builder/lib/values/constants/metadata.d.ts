import { Constant } from './base';
export declare type MetadataValue = string | Constant | ReadonlyArray<Metadata>;
export declare class Metadata extends Constant {
    readonly value: MetadataValue;
    private privSelfReference;
    private privDistinct;
    constructor(value: MetadataValue);
    readonly selfReference: boolean;
    readonly distinct: boolean;
    addSelfReference(): this;
    markDistinct(): this;
    isEqual(to: Constant): boolean;
    toString(): string;
}
