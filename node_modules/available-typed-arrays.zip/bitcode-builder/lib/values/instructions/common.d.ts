import { Type } from '../../types';
export declare function getAggrFieldType(aggrTy: Type, index: number): Type;
export declare function checkAlignment(alignment: number): void;
