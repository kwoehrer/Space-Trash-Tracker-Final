import * as values from '../';
import { Instruction } from './base';
export declare class Branch extends Instruction {
    readonly condition: values.Value;
    readonly onTrue: values.BasicBlock;
    readonly onFalse: values.BasicBlock;
    constructor(condition: values.Value, onTrue: values.BasicBlock, onFalse: values.BasicBlock);
}
