import * as values from '../';
import { Type } from '../../types';
import { Instruction } from './base';
export interface IPhiEdge {
    readonly fromBlock: values.BasicBlock;
    readonly value: values.Value;
}
export declare class Phi extends Instruction {
    private readonly privEdges;
    constructor(edgeOrTy: IPhiEdge | Type);
    readonly edges: ReadonlyArray<IPhiEdge>;
    addEdge(edge: IPhiEdge): void;
}
