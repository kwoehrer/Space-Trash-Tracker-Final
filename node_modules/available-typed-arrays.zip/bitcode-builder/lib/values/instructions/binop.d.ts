import * as values from '../';
import { Instruction } from './base';
export declare type BinopType = 'add' | 'sub' | 'mul' | 'udiv' | 'sdiv' | 'urem' | 'srem' | 'shl' | 'lshr' | 'ashr' | 'and' | 'or' | 'xor';
export declare class Binop extends Instruction {
    readonly binopType: BinopType;
    readonly left: values.Value;
    readonly right: values.Value;
    constructor(binopType: BinopType, left: values.Value, right: values.Value);
}
