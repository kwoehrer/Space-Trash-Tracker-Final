import * as values from '../';
import { Instruction } from './base';
export declare type ICmpPredicate = 'eq' | 'ne' | 'ugt' | 'uge' | 'ult' | 'ule' | 'sgt' | 'sge' | 'slt' | 'sle';
export declare class ICmp extends Instruction {
    readonly predicate: ICmpPredicate;
    readonly left: values.Value;
    readonly right: values.Value;
    constructor(predicate: ICmpPredicate, left: values.Value, right: values.Value);
}
