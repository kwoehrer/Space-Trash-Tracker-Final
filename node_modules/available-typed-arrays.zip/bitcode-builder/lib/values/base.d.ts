import { Type } from '../types';
import * as values from './';
export declare abstract class Value {
    readonly ty: Type;
    constructor(ty: Type);
    abstract toString(): string;
    inspect(): string;
    isArgument(): boolean;
    isGlobal(): boolean;
    isBasicBlock(): boolean;
    isConstant(): boolean;
    isInstruction(): boolean;
    toArgument(): values.Argument;
    toGlobal(): values.Global;
    toBasicBlock(): values.BasicBlock;
    toConstant(): values.constants.Constant;
    toInstruction(): values.instructions.Instruction;
}
