import { AttributeList } from '../attribute-list';
import { Linkage } from '../linkage';
import { Type } from '../types';
import { Value } from './base';
import { Constant } from './constants';
export declare class Global extends Value {
    readonly name: string;
    readonly init: Constant | undefined;
    attrs: AttributeList;
    linkage: Linkage;
    private privIsConstant;
    constructor(ty: Type, name: string, init?: Constant | undefined);
    hasConstantValue(): boolean;
    markConstant(): void;
    toString(): string;
}
