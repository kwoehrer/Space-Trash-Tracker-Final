import { Pass } from './base';
export declare class Verify extends Pass {
    private readonly globals;
    run(): void;
    private visitFunction(fn);
    private computeReachable(fn);
    private propagateReachable(reachable, bb);
    private computeLiveness(reachable, fn);
    private propagateBlockLiveness(live, reachable, bb);
    private checkBlock(liveMap, bb);
}
