import * as values from '../../values';
import { Type } from '../base';
import { Field } from './field';
export declare class Struct extends Type {
    readonly name: string | undefined;
    private readonly privFields;
    private fieldMap;
    private finalized;
    constructor(name?: string | undefined);
    readonly typeString: string;
    readonly anonymousTypeString: string;
    readonly fields: ReadonlyArray<Field>;
    isEqual(to: Type): boolean;
    val(map: {
        [key: string]: values.constants.Constant;
    }): values.constants.Struct;
    finalize(): void;
    addField(ty: Type, name: string): Field;
    hasField(name: string): boolean;
    lookupField(name: string): Field;
    getField(index: number): Field;
    protected checkFinalized(): void;
}
export { Field };
