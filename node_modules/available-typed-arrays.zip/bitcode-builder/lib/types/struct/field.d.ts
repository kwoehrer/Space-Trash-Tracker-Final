import { Type } from '../base';
export declare class Field {
    readonly ty: Type;
    readonly name: string;
    readonly index: number;
    constructor(ty: Type, name: string, index: number);
}
