import * as values from '../values';
import { Type } from './base';
export declare class Pointer extends Type {
    readonly to: Type;
    constructor(to: Type);
    isEqual(to: Type): boolean;
    val(_: null): values.constants.Null;
}
